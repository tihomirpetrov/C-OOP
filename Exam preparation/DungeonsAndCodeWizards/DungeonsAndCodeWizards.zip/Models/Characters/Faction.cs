﻿namespace DungeonsAndCodeWizards.Models.Characters
{
    public enum Faction
    {
        CSharp,
        Java
    };
}