﻿namespace DungeonsAndCodeWizards
{
    public interface IReader
    {
        string ReadLine();
    }
}