﻿namespace P01.Logger.Layouts.Contracts
{
    public interface ILayout
    {
        string Format { get; }
    }
}