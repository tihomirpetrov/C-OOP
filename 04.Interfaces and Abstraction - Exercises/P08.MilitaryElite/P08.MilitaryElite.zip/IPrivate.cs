﻿namespace P08.MilitaryElite
{
    public interface IPrivate : ISoldier
    {
        decimal Salary { get;}
    }
}
