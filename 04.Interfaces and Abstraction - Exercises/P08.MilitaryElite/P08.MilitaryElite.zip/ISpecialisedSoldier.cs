﻿using System.Collections.Generic;

namespace P08.MilitaryElite
{
    public interface ISpecialisedSoldier
    {
        string Corps { get; }
    }
}
