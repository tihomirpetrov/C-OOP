﻿namespace P08.MilitaryElite
{
    public interface ISpy: ISoldier
    {
        int CodeNumber { get; }
    }
}
