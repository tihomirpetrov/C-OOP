﻿namespace P05.BorderControl
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}