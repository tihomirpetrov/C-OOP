﻿namespace P07.FoodShortage
{
    public interface IIdentifiable
    {
        string Birthdate { get; }
    }
}