﻿namespace P04.BarrackWars_TheCommandsStrikeBack.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
