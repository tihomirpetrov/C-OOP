﻿namespace P04.BarrackWars_TheCommandsStrikeBack.Contracts
{
    public interface IAttacker
    {
        int AttackDamage { get; }
    }
}
