﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P04.BarrackWars_TheCommandsStrikeBack.Contracts
{
    public interface IUnit : IDestroyable, IAttacker
    {

    }
}
