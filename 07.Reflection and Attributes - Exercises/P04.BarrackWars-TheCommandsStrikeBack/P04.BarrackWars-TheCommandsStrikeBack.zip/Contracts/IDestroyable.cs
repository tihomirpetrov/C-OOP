﻿namespace P04.BarrackWars_TheCommandsStrikeBack.Contracts
{
    public interface IDestroyable
    {
        int Health { get; set; }
    }
}
