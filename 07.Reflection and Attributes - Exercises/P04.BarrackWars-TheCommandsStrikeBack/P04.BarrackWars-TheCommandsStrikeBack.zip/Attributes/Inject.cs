﻿namespace P04.BarrackWars_TheCommandsStrikeBack.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Field)]
    public class InjectAttribute : Attribute
    {
    }
}
