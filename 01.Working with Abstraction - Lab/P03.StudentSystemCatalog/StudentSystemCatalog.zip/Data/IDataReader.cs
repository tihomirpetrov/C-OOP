﻿namespace StudentSystemCatalog.Data
{
    public interface IDataReader
    {
        string Read();
    }
}
