﻿namespace StudentSystemCatalog.Data
{
    public interface IDataWriter
    {
        void Write(object obj);
    }
}
