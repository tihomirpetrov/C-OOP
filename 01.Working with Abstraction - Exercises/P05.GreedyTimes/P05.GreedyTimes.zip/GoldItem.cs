﻿namespace P05.GreedyTimes
{
    public class GoldItem : Item
    {
        public GoldItem(string key, long value)
        {
            Key = key;
            Value = value;
        }
    }
}