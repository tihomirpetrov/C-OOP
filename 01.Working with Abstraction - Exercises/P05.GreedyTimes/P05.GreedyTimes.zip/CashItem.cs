﻿namespace P05.GreedyTimes
{
    public class CashItem : Item
    {
        public CashItem(string key, long value)
        {
            Key = key;
            Value = value;
        }
    }
}