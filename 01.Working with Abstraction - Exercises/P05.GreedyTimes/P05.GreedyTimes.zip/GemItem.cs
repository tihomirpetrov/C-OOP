﻿namespace P05.GreedyTimes
{
    public class GemItem : Item
    {
        public GemItem(string key, long value)
        {
            Key = key;
            Value = value;
        }
    }
}