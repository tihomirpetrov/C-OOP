﻿namespace StorageMaster.Entities.Vehicles
{
	public class Truck : Vehicle
	{
		public Truck()
			: base(capacity: 5)
		{
		}
	}
}